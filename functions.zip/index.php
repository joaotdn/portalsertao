<?php 
get_header();

get_template_part('parts/home-features');
get_template_part('parts/home-videos');
get_template_part('parts/home-play');
get_template_part('parts/home-varieties');

get_footer();
?>