<div class="radios-online-player position-fixed">
    <div class="w-100 bg-danger d-flex align-items-center">
        <div id="bars">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
        <div class="">
            <span class="ps-radios-online--name text-white"></span>
            <a href="#" class="ps-radios-online--close text-white d-inline-block ps-2">
                <i class="fa-solid fa-xmark"></i>
            </a>
        </div>
    </div>
    <audio src="#" id="ps-radios-online--player"></audio>
</div>