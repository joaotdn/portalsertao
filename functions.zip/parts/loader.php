<div data-loader class="epg-loader <?php echo $args['class']; ?> align-middle rotating py-3 width-100 text-center">
    <i class="fa-solid fa-spinner opacity-75 text-primary"></i>
</div>